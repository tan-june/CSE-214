package cse214hw2;

public interface Evaluator {
    //evaluate method
    double evaluate(String expressionString);

}
